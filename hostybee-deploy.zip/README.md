# Project Bolt - Deployment Package

## Estructura del Proyecto
- `/frontend`: Aplicación React/Vite
- `/backend`: API Node.js/Express

## Instrucciones de Despliegue
1. Descomprimir el archivo
2. Configurar las variables de entorno
3. Ejecutar `npm install` en ambos directorios
4. Seguir las instrucciones de Hostybee para el despliegue

## Variables de Entorno Requeridas
- API_V1_STR
- PROJECT_NAME
- SECRET_KEY
- BELCORP_USERNAME
- BELCORP_PASSWORD
- WHATSAPP_API_KEY
- WHATSAPP_PHONE_NUMBER
