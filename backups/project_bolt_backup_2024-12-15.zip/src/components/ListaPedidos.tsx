import React, { useState } from 'react';
import type { Pedido } from '../types/types';
import ConfirmacionPedido from './ConfirmacionPedido';
import { Clock } from 'lucide-react';

interface ListaPedidosProps {
  pedidos: Pedido[];
  onCambiarEstado: (id: number, estado: Pedido['estado']) => void;
  onEditarPedido: (pedido: Pedido) => void;
}

export default function ListaPedidos({ pedidos, onCambiarEstado, onEditarPedido }: ListaPedidosProps) {
  const [pedidoEnAdvertencia, setPedidoEnAdvertencia] = useState<Pedido | null>(null);
  const [pedidoConfirmado, setPedidoConfirmado] = useState<Pedido | null>(null);

  const handleConfirmarAdvertencia = () => {
    if (pedidoEnAdvertencia) {
      onCambiarEstado(pedidoEnAdvertencia.id, 'completado');
      setPedidoConfirmado(pedidoEnAdvertencia);
      setPedidoEnAdvertencia(null);
    }
  };

  const handleCancelarAdvertencia = () => {
    setPedidoEnAdvertencia(null);
  };

  const handleCerrarConfirmacion = () => {
    setPedidoConfirmado(null);
  };

  const handleCompletar = (pedido: Pedido) => {
    setPedidoEnAdvertencia(pedido);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold mb-4">Pedidos</h2>
      
      {pedidoEnAdvertencia && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center mb-4">
              <div className="bg-yellow-100 p-2 rounded-full mr-3">
                <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold">¡Atención!</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Hola Chica Inova, Recuerda verificar muy bien tu pedido.
              Cualquier error en el código será tu responsabilidad no la de nosotros.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelarAdvertencia}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmarAdvertencia}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

      {pedidoConfirmado && (
        <ConfirmacionPedido
          pedido={pedidoConfirmado}
          onClose={handleCerrarConfirmacion}
        />
      )}

      {pedidos.map((pedido) => (
        <div key={pedido.id} className="bg-white p-4 rounded-lg shadow">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                Pedido #{pedido.id}
                {pedido.estado === 'pendiente' && (
                  <span className="inline-flex items-center">
                    <Clock size={16} className="text-yellow-500" />
                    <span className="text-sm text-yellow-500 ml-1">Pendiente</span>
                  </span>
                )}
              </h3>
              <span className="text-gray-600">Total: ${pedido.total}</span>
            </div>
            <div className="text-sm text-gray-600">
              {pedido.productos.map((producto) => (
                <div key={producto.id}>
                  <p>
                    {producto.nombre} - ${producto.precio} x {producto.cantidad}
                    <br />
                    <span className="text-xs">
                      Catálogo: {producto.catalogo} • Código: {producto.codigo} • Empaque: {producto.empaque}
                      {producto.empaque === 'Incluye' && producto.descripcionIncluye && (
                        <> • Incluye: {producto.descripcionIncluye}</>
                      )}
                    </span>
                  </p>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t pt-3">
            <div className="flex justify-end gap-2">
              {pedido.estado === 'pendiente' && (
                <>
                  <button
                    onClick={() => handleCompletar(pedido)}
                    className="px-3 py-1 text-sm font-medium text-white bg-green-600 rounded hover:bg-green-700 transition-colors"
                    title="Completar pedido"
                  >
                    Completar
                  </button>
                  <button
                    onClick={() => onCambiarEstado(pedido.id, 'cancelado')}
                    className="px-3 py-1 text-sm font-medium text-white bg-red-600 rounded hover:bg-red-700 transition-colors"
                    title="Cancelar pedido"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => onEditarPedido(pedido)}
                    className="px-3 py-1 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700 transition-colors"
                    title="Editar pedido"
                  >
                    Editar
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}