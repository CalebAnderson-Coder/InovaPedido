import React, { useState } from 'react';
import { Plus, Package, Barcode, Book, ListChecks } from 'lucide-react';
import type { Producto } from '../types/types';
import { CATALOGOS, TIPOS_EMPAQUE } from '../constants/catalogos';

interface ProductoFormProps {
  onAgregarProducto: (producto: Producto) => void;
}

export default function ProductoForm({ onAgregarProducto }: ProductoFormProps) {
  const [formData, setFormData] = useState({
    nombre: '',
    precio: '',
    cantidad: '',
    catalogo: '',
    codigo: '',
    empaque: '',
    descripcionIncluye: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validación básica
    if (!formData.nombre.trim()) {
      alert('Por favor ingrese el nombre del producto');
      return;
    }
    if (!formData.precio || parseFloat(formData.precio) <= 0) {
      alert('Por favor ingrese un precio válido');
      return;
    }
    if (!formData.cantidad || parseInt(formData.cantidad) <= 0) {
      alert('Por favor ingrese una cantidad válida');
      return;
    }
    if (!formData.catalogo) {
      alert('Por favor seleccione un catálogo');
      return;
    }
    if (!formData.codigo.trim()) {
      alert('Por favor ingrese el código del producto');
      return;
    }
    if (!formData.empaque) {
      alert('Por favor seleccione un tipo de empaque');
      return;
    }
    if (formData.empaque === 'Incluye' && !formData.descripcionIncluye.trim()) {
      alert('Por favor ingrese la descripción de lo que incluye');
      return;
    }

    const nuevoProducto: Producto = {
      id: Date.now(),
      nombre: formData.nombre.trim(),
      precio: parseFloat(formData.precio),
      cantidad: parseInt(formData.cantidad),
      catalogo: formData.catalogo as Producto['catalogo'],
      codigo: formData.codigo.trim(),
      empaque: formData.empaque as Producto['empaque'],
      ...(formData.empaque === 'Incluye' && { descripcionIncluye: formData.descripcionIncluye.trim() }),
    };

    try {
      onAgregarProducto(nuevoProducto);
      
      // Limpiar el formulario solo después de agregar exitosamente
      setFormData({
        nombre: '',
        precio: '',
        cantidad: '',
        catalogo: '',
        codigo: '',
        empaque: '',
        descripcionIncluye: '',
      });
    } catch (error) {
      alert('Hubo un error al agregar el producto. Por favor intente de nuevo.');
      console.error('Error al agregar producto:', error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Catálogo
          </label>
          <div className="relative">
            <Book className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <select
              name="catalogo"
              value={formData.catalogo}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Seleccionar catálogo</option>
              {CATALOGOS.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Código
          </label>
          <div className="relative">
            <Barcode className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              name="codigo"
              value={formData.codigo}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Código del producto"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Nombre del producto
          </label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nombre del producto"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Empaque
          </label>
          <div className="relative">
            <Package className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <select
              name="empaque"
              value={formData.empaque}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Tipo de empaque</option>
              {TIPOS_EMPAQUE.map(tipo => (
                <option key={tipo} value={tipo}>{tipo}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Precio
          </label>
          <input
            type="number"
            name="precio"
            value={formData.precio}
            onChange={handleChange}
            step="0.01"
            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Precio"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Cantidad
          </label>
          <input
            type="number"
            name="cantidad"
            value={formData.cantidad}
            onChange={handleChange}
            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Cantidad"
          />
        </div>

        {formData.empaque === 'Incluye' && (
          <div className="space-y-2 md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Descripción de lo que incluye
            </label>
            <div className="relative">
              <ListChecks className="absolute left-3 top-3 text-gray-400" size={20} />
              <textarea
                name="descripcionIncluye"
                value={formData.descripcionIncluye}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Detalla los items incluidos"
                rows={3}
              />
            </div>
          </div>
        )}
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2"
      >
        <Plus size={20} />
        Agregar Producto
      </button>
    </form>
  );
}