import React from 'react';
import { ShoppingBag } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-600 text-white p-4 shadow-md">
        <div className="container mx-auto flex items-center gap-2">
          <ShoppingBag size={24} />
          <h1 className="text-2xl font-bold">Sistema de Pedidos</h1>
        </div>
      </header>

      <main className="container mx-auto p-4">
        {children}
      </main>
    </div>
  );
}