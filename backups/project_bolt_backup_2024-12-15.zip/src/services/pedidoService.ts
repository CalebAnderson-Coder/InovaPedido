import { Pedido } from '../types/types';
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, BorderStyle, AlignmentType } from 'docx';
import { saveAs } from 'file-saver';

export const generarDocumentoPedido = async (pedido: Pedido) => {
  try {
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: "INOVASHOP",
                bold: true,
                size: 32,
              }),
            ],
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: pedido.vendedora && pedido.zona ? 
                     `${pedido.vendedora} - ${pedido.zona}` : 
                     'Vendedora - Zona',
                bold: true,
                size: 24,
              }),
            ],
            alignment: AlignmentType.CENTER,
            spacing: {
              after: 200,
            },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `Fecha: ${new Date().toLocaleDateString('es-ES', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}`,
                size: 16,
              }),
            ],
            spacing: { after: 200 },
          }),
          new Table({
            width: { size: 100, type: 'pct' },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 1 },
              bottom: { style: BorderStyle.SINGLE, size: 1 },
              left: { style: BorderStyle.SINGLE, size: 1 },
              right: { style: BorderStyle.SINGLE, size: 1 },
              insideHorizontal: { style: BorderStyle.SINGLE, size: 1 },
              insideVertical: { style: BorderStyle.SINGLE, size: 1 },
            },
            rows: [
              new TableRow({
                tableHeader: true,
                children: [
                  new TableCell({
                    width: { size: 40, type: 'pct' },
                    children: [new Paragraph({
                      children: [new TextRun({ text: 'Producto', bold: true })],
                      alignment: AlignmentType.CENTER,
                    })],
                    shading: { fill: 'E5E7EB' },
                  }),
                  new TableCell({
                    width: { size: 20, type: 'pct' },
                    children: [new Paragraph({
                      children: [new TextRun({ text: 'Cantidad', bold: true })],
                      alignment: AlignmentType.CENTER,
                    })],
                    shading: { fill: 'E5E7EB' },
                  }),
                  new TableCell({
                    width: { size: 20, type: 'pct' },
                    children: [new Paragraph({
                      children: [new TextRun({ text: 'Precio', bold: true })],
                      alignment: AlignmentType.CENTER,
                    })],
                    shading: { fill: 'E5E7EB' },
                  }),
                  new TableCell({
                    width: { size: 20, type: 'pct' },
                    children: [new Paragraph({
                      children: [new TextRun({ text: 'Total', bold: true })],
                      alignment: AlignmentType.CENTER,
                    })],
                    shading: { fill: 'E5E7EB' },
                  }),
                ],
              }),
              ...pedido.productos.map(
                (producto) =>
                  new TableRow({
                    children: [
                      new TableCell({
                        children: [new Paragraph({
                          children: [new TextRun({ text: producto.nombre })],
                          alignment: AlignmentType.LEFT,
                        })],
                      }),
                      new TableCell({
                        children: [new Paragraph({
                          children: [new TextRun({ text: `${producto.cantidad} unidades` })],
                          alignment: AlignmentType.CENTER,
                        })],
                      }),
                      new TableCell({
                        children: [new Paragraph({
                          children: [new TextRun({ text: `$${producto.precio.toFixed(2)}` })],
                          alignment: AlignmentType.RIGHT,
                        })],
                      }),
                      new TableCell({
                        children: [new Paragraph({
                          children: [new TextRun({ text: `$${(producto.precio * producto.cantidad).toFixed(2)}` })],
                          alignment: AlignmentType.RIGHT,
                        })],
                      }),
                    ],
                  })
              ),
              new TableRow({
                children: [
                  new TableCell({
                    columnSpan: 3,
                    children: [new Paragraph({
                      children: [new TextRun({ text: 'Total del Pedido:', bold: true })],
                      alignment: AlignmentType.RIGHT,
                    })],
                  }),
                  new TableCell({
                    children: [new Paragraph({
                      children: [new TextRun({ text: `$${pedido.total.toFixed(2)}`, bold: true })],
                      alignment: AlignmentType.RIGHT,
                    })],
                    shading: { fill: 'E5E7EB' },
                  }),
                ],
              }),
            ],
          }),
        ],
      }],
    });

    const buffer = await Packer.toBlob(doc);
    saveAs(buffer, `Pedido_${pedido.vendedora || 'Vendedora'}_${new Date().toISOString().split('T')[0]}.docx`);
  } catch (error) {
    console.error('Error al generar el documento:', error);
    throw new Error('Error al generar el documento del pedido');
  }
};
